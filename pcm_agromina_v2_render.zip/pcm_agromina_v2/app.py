import os, re, json, sqlite3, secrets, hashlib, hmac, time, uuid
from pathlib import Path
from datetime import datetime, timedelta
from contextlib import contextmanager
import fitz
from fastapi import FastAPI, Request, HTTPException, UploadFile, File, Form, Depends
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from itsdangerous import URLSafeTimedSerializer, BadSignature
from starlette.middleware.sessions import SessionMiddleware

ROOT=Path(__file__).parent
DATA=Path(os.environ.get('DATA_DIR',ROOT/'data'))
DATA.mkdir(parents=True,exist_ok=True)
(DATA/'uploads').mkdir(exist_ok=True)
DB=DATA/'pcm.sqlite3'
SECRET=os.environ.get('APP_SECRET') or secrets.token_hex(32)
if 'APP_SECRET' not in os.environ: print('AVISO: defina APP_SECRET persistente em produção.')
app=FastAPI(title='PCM Agromina v2',docs_url=None,redoc_url=None)
app.add_middleware(SessionMiddleware,secret_key=SECRET,same_site='lax',https_only=os.environ.get('HTTPS_ONLY','0')=='1')
app.mount('/static',StaticFiles(directory=ROOT/'static'),name='static')

def hash_pw(pw,salt=None):
    salt=salt or secrets.token_hex(16)
    return salt+'$'+hashlib.pbkdf2_hmac('sha256',pw.encode(),bytes.fromhex(salt),240000).hex()
def check_pw(pw,stored):
    try:
        salt,_=stored.split('$'); return hmac.compare_digest(hash_pw(pw,salt),stored)
    except Exception: return False
@contextmanager
def conn():
    c=sqlite3.connect(DB,timeout=20)
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA journal_mode=WAL')
    try: yield c; c.commit()
    finally: c.close()

def init():
    with conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,code TEXT UNIQUE NOT NULL,scheduled TEXT,supervisor TEXT DEFAULT 'Pedro',source TEXT,created TEXT NOT NULL,closed TEXT);
        CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY,order_id INTEGER NOT NULL REFERENCES orders(id),number TEXT NOT NULL,sector TEXT NOT NULL DEFAULT 'A conferir',equipment TEXT NOT NULL DEFAULT '',activity TEXT NOT NULL DEFAULT '',frequency TEXT DEFAULT '',status TEXT NOT NULL DEFAULT 'sem_retorno',note TEXT NOT NULL DEFAULT '',risk TEXT NOT NULL DEFAULT 'normal',reason TEXT NOT NULL DEFAULT '',updated TEXT,updated_by TEXT,UNIQUE(order_id,number));
        CREATE TABLE IF NOT EXISTS photos(id INTEGER PRIMARY KEY,item_id INTEGER NOT NULL REFERENCES items(id),file TEXT NOT NULL,original TEXT,created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,at TEXT NOT NULL,actor TEXT NOT NULL,action TEXT NOT NULL,details TEXT NOT NULL);
        ''')
        for role,name,env in [('gerencia','gerencia','ADMIN_PASSWORD'),('tecnico','pedro','PEDRO_PASSWORD')]:
            if not c.execute('SELECT 1 FROM users WHERE username=?',(name,)).fetchone():
                pw=os.environ.get(env)
                if pw: c.execute('INSERT INTO users(username,password,role) VALUES(?,?,?)',(name,hash_pw(pw),role))
                else: print(f'AVISO: {name} não criado. Defina {env} no ambiente.')
init()

def user(req:Request):
    uid=req.session.get('uid')
    if not uid: raise HTTPException(401,'Faça login')
    with conn() as c: u=c.execute('SELECT id,username,role FROM users WHERE id=?',(uid,)).fetchone()
    if not u: raise HTTPException(401,'Sessão inválida')
    return dict(u)
def admin(u=Depends(user)):
    if u['role']!='gerencia': raise HTTPException(403,'Apenas gerência')
    return u
def audit(c,u,action,details): c.execute('INSERT INTO events(at,actor,action,details) VALUES(?,?,?,?)',(datetime.now().isoformat(timespec='seconds'),u['username'],action,json.dumps(details,ensure_ascii=False)))
def obj(r): return dict(r) if r else None
@app.get('/')
def home(): return FileResponse(ROOT/'static'/'index.html')
@app.post('/api/login')
async def login(req:Request):
    b=await req.json()
    with conn() as c: u=c.execute('SELECT * FROM users WHERE username=?',(str(b.get('username','')).lower(),)).fetchone()
    if not u or not check_pw(str(b.get('password','')),u['password']): raise HTTPException(401,'Credenciais inválidas')
    req.session.clear();req.session['uid']=u['id'];return {'username':u['username'],'role':u['role']}
@app.post('/api/logout')
def logout(req:Request): req.session.clear();return {'ok':True}
@app.get('/api/me')
def me(u=Depends(user)): return u
@app.get('/api/orders')
def orders(u=Depends(user)):
    with conn() as c:
        rows=c.execute('''SELECT o.*,count(i.id) total,sum(CASE WHEN i.status='realizado' THEN 1 ELSE 0 END) realizados,sum(CASE WHEN i.status='pendente' THEN 1 ELSE 0 END) pendentes,sum(CASE WHEN i.status='sem_retorno' THEN 1 ELSE 0 END) sem_retorno FROM orders o LEFT JOIN items i ON i.order_id=o.id GROUP BY o.id ORDER BY o.id DESC''').fetchall()
        return [obj(r) for r in rows]
@app.get('/api/orders/{oid}')
def order(oid:int,u=Depends(user)):
    with conn() as c:
        o=c.execute('SELECT * FROM orders WHERE id=?',(oid,)).fetchone()
        if not o: raise HTTPException(404,'OS não encontrada')
        its=[obj(x) for x in c.execute('SELECT * FROM items WHERE order_id=? ORDER BY CAST(number AS INTEGER),number',(oid,))]
        for i in its: i['photos']=[obj(x) for x in c.execute('SELECT id,original,created FROM photos WHERE item_id=?',(i['id'],))]
        return {'order':obj(o),'items':its}

# PDFs textuais de layouts distintos exigem revisão humana antes de confirmar importação.
def parse_pdf(data):
    try:
        doc=fitz.open(stream=data,filetype='pdf')
        text='\n'.join(page.get_text(sort=True) for page in doc)
    except Exception: raise HTTPException(400,'PDF inválido ou ilegível')
    if not text.strip(): raise HTTPException(422,'PDF sem texto selecionável. Necessário PDF digital, não imagem digitalizada.')
    code=re.search(r'OS[-\s]*SLZ[-\s]*(20\d{2})[-\s]*(\d{3,5})',text,re.I)
    code=f'OS-SLZ-{code.group(1)}-{int(code.group(2)):04d}' if code else ''
    dt=re.search(r'\b(\d{2})[/\-](\d{2})[/\-](20\d{2})\b',text)
    date=f'{dt.group(3)}-{dt.group(2)}-{dt.group(1)}' if dt else ''
    lines=[re.sub(r'\s+',' ',x).strip() for x in text.splitlines() if x.strip()]
    items=[]
    for line in lines:
        m=re.match(r'^(?:ITEM\s*)?(\d{1,3})\s*[.\-\)||]\s*(.{8,})$',line,re.I)
        if m and not re.search(r'^(?:OS|DATA|SUPERVISOR|PÁGINA)',m.group(2),re.I):
            n=m.group(1)
            if n not in [x['number'] for x in items]:
                bits=[x.strip() for x in re.split(r'\s*\|\s*|\s{2,}',m.group(2)) if x.strip()]
                items.append({'number':n,'sector':bits[0] if len(bits)>2 else 'A conferir','equipment':bits[1] if len(bits)>2 else (bits[0] if len(bits)>1 else ''),'activity':bits[-1], 'frequency':''})
    return {'code':code,'scheduled':date,'supervisor':'Pedro','items':items,'extracted_lines':lines[:350],'warning':'Confira número, setor, equipamento, atividade e quantidade de itens antes de confirmar. A leitura automática pode ser incompleta.'}
@app.post('/api/pdf/preview')
async def preview(file:UploadFile=File(...),u=Depends(admin)):
    if file.content_type not in ('application/pdf','application/octet-stream'): raise HTTPException(400,'Envie um PDF')
    data=await file.read(12*1024*1024+1)
    if len(data)>12*1024*1024: raise HTTPException(413,'PDF maior que 12 MB')
    return parse_pdf(data)
@app.post('/api/orders/import')
async def import_order(req:Request,u=Depends(admin)):
    b=await req.json();code=str(b.get('code','')).strip().upper();items=b.get('items',[])
    if not re.fullmatch(r'OS-SLZ-20\d{2}-\d{4}',code): raise HTTPException(422,'Código inválido. Ex.: OS-SLZ-2026-0003')
    if not isinstance(items,list) or not 1<=len(items)<=250: raise HTTPException(422,'Informe entre 1 e 250 itens')
    if len({str(i.get('number','')).strip() for i in items})!=len(items): raise HTTPException(422,'Números de item repetidos')
    with conn() as c:
        if c.execute('SELECT 1 FROM orders WHERE code=?',(code,)).fetchone(): raise HTTPException(409,'OS já cadastrada; importação duplicada bloqueada')
        # Bloqueia avanço de sequência com OS anterior ainda sem fechamento.
        last=c.execute('SELECT code,closed FROM orders ORDER BY id DESC LIMIT 1').fetchone()
        if last and not last['closed']: raise HTTPException(409,f"Feche {last['code']} antes de importar nova OS")
        cur=c.execute('INSERT INTO orders(code,scheduled,supervisor,source,created) VALUES(?,?,?,?,?)',(code,str(b.get('scheduled',''))[:10],str(b.get('supervisor','Pedro'))[:80],'PDF revisado',datetime.now().isoformat(timespec='seconds')))
        oid=cur.lastrowid
        for i in items:
            number=str(i.get('number','')).strip()[:12]
            if not number: raise HTTPException(422,'Item sem número')
            c.execute('INSERT INTO items(order_id,number,sector,equipment,activity,frequency) VALUES(?,?,?,?,?,?)',(oid,number,str(i.get('sector','A conferir'))[:120],str(i.get('equipment',''))[:180],str(i.get('activity',''))[:600],str(i.get('frequency',''))[:40]))
        audit(c,u,'importar_os',{'code':code,'items':len(items)})
        return {'id':oid,'code':code}
@app.patch('/api/items/{iid}')
async def update_item(iid:int,req:Request,u=Depends(user)):
    b=await req.json();status=b.get('status')
    if status not in ('realizado','pendente','sem_retorno','nao_executado'): raise HTTPException(422,'Status inválido')
    note=str(b.get('note',''))[:5000];risk=b.get('risk','normal');reason=str(b.get('reason',''))[:2000]
    if risk not in ('normal','corretiva','critico'): raise HTTPException(422,'Risco inválido')
    if status=='nao_executado' and not reason.strip(): raise HTTPException(422,'Informe o motivo da não execução')
    with conn() as c:
        row=c.execute('SELECT i.id,o.closed,o.code FROM items i JOIN orders o ON o.id=i.order_id WHERE i.id=?',(iid,)).fetchone()
        if not row: raise HTTPException(404,'Item não encontrado')
        if row['closed']: raise HTTPException(409,'OS fechada; alterações bloqueadas')
        c.execute('UPDATE items SET status=?,note=?,risk=?,reason=?,updated=?,updated_by=? WHERE id=?',(status,note,risk,reason,datetime.now().isoformat(timespec='seconds'),u['username'],iid))
        audit(c,u,'inspecao',{'os':row['code'],'item':iid,'status':status,'risk':risk})
    return {'ok':True}
@app.post('/api/items/{iid}/photos')
async def upload_photo(iid:int,file:UploadFile=File(...),u=Depends(user)):
    if file.content_type not in ('image/jpeg','image/png','image/webp'): raise HTTPException(415,'Use JPG, PNG ou WebP')
    data=await file.read(8*1024*1024+1)
    if len(data)>8*1024*1024: raise HTTPException(413,'Foto maior que 8 MB')
    ext={'image/jpeg':'.jpg','image/png':'.png','image/webp':'.webp'}[file.content_type]
    if not (data.startswith(b'\xff\xd8') or data.startswith(b'\x89PNG\r\n\x1a\n') or data.startswith(b'RIFF')): raise HTTPException(415,'Arquivo não parece ser uma imagem válida')
    with conn() as c:
        row=c.execute('SELECT o.closed FROM items i JOIN orders o ON o.id=i.order_id WHERE i.id=?',(iid,)).fetchone()
        if not row: raise HTTPException(404,'Item não encontrado')
        if row['closed']: raise HTTPException(409,'OS fechada')
        name=uuid.uuid4().hex+ext;(DATA/'uploads'/name).write_bytes(data)
        cur=c.execute('INSERT INTO photos(item_id,file,original,created) VALUES(?,?,?,?)',(iid,name,str(file.filename or '')[:200],datetime.now().isoformat(timespec='seconds')))
        audit(c,u,'foto',{'item':iid,'photo':cur.lastrowid})
        return {'id':cur.lastrowid}
@app.get('/api/photos/{pid}')
def photo(pid:int,u=Depends(user)):
    with conn() as c: r=c.execute('SELECT file FROM photos WHERE id=?',(pid,)).fetchone()
    if not r: raise HTTPException(404,'Foto não encontrada')
    p=DATA/'uploads'/r['file']
    if not p.is_file(): raise HTTPException(404,'Arquivo ausente')
    return FileResponse(p)
@app.post('/api/orders/{oid}/close')
def close_order(oid:int,u=Depends(admin)):
    with conn() as c:
        r=c.execute('SELECT * FROM orders WHERE id=?',(oid,)).fetchone()
        if not r: raise HTTPException(404,'OS não encontrada')
        if r['closed']: raise HTTPException(409,'OS já fechada')
        # Sem retorno é preservado como não comprovado, não como não executado.
        c.execute('UPDATE orders SET closed=? WHERE id=?',(datetime.now().isoformat(timespec='seconds'),oid))
        audit(c,u,'fechar_os',{'code':r['code']})
    return {'ok':True}
@app.get('/api/orders/{oid}/export')
def export(oid:int,u=Depends(user)):
    with conn() as c:
        o=c.execute('SELECT * FROM orders WHERE id=?',(oid,)).fetchone()
        if not o: raise HTTPException(404,'OS não encontrada')
        items=[obj(r) for r in c.execute('SELECT * FROM items WHERE order_id=? ORDER BY CAST(number AS INTEGER)',(oid,))]
        for i in items:i['photos']=[obj(r) for r in c.execute('SELECT id,original,created FROM photos WHERE item_id=?',(i['id'],))]
    return {'order':obj(o),'items':items,'exported_at':datetime.now().isoformat(timespec='seconds')}
@app.get('/api/events')
def events(u=Depends(admin)):
    with conn() as c: return [obj(x) for x in c.execute('SELECT * FROM events ORDER BY id DESC LIMIT 100')]
