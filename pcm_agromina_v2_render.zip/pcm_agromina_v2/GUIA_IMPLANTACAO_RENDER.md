# PCM Agromina 2.0 — implantação gerenciada (Render)

## Escolha técnica desta versão

A versão 2.0 fornecida **usa SQLite**, não PostgreSQL. Para publicar sem reescrever o backend, a opção inicial é **um único serviço web Render com disco persistente** para banco SQLite e fotos. Isso oferece um banco centralizado acessível pelos dois perfis, mas **não é uma arquitetura de alta disponibilidade**: o serviço não pode escalar horizontalmente com esse banco, e o disco precisa de backups externos. PostgreSQL + armazenamento de objetos é uma **migração futura**, não um recurso já implementado.

## 1. Preparar o repositório

1. Extraia o ZIP do projeto em uma pasta privada no computador.
2. Crie um repositório GitHub **privado** e envie os arquivos do projeto (incluindo `render.yaml`, `Dockerfile`, `app.py`, `static/` e `requirements.txt`).
3. **Nunca** envie senhas, arquivos `.env`, banco `data/` ou fotos para o repositório. O `.dockerignore` já exclui esses itens da imagem Docker, mas use também um `.gitignore`.

## 2. Criar o serviço no Render

1. Crie uma conta no Render e conecte o GitHub com acesso ao repositório privado.
2. No painel Render, escolha **New > Blueprint** e selecione o repositório com `render.yaml`. Confirme os recursos e preços mostrados pelo provedor antes de criar.
3. O Blueprint descreve um **Web Service Docker** chamado `pcm-agromina`, região `ohio`, plano `starter`, disco persistente de **1 GB** em `/app/data` e health check `/`.
4. Informe as variáveis solicitadas `ADMIN_PASSWORD` e `PEDRO_PASSWORD`, com senhas fortes, distintas e guardadas em gerenciador de senhas. `APP_SECRET` será gerado pelo Blueprint; mantenha-o estável em futuras publicações.
5. Confirme `DATA_DIR=/app/data` e `HTTPS_ONLY=1` e faça o deploy.
6. Aguarde o status de serviço ativo e abra a URL HTTPS `https://<seu-servico>.onrender.com` fornecida pelo Render. **Não invente a URL antes da criação.**

## 3. Acesso e primeiro teste

1. Entre como `gerencia` com `ADMIN_PASSWORD` e como `pedro` com `PEDRO_PASSWORD`, em navegadores/dispositivos diferentes.
2. **Não importe uma OS real como teste inicial**: use um PDF de teste com dados fictícios e confira a extração completa, número, data, setor, equipamento, atividade e frequência.
3. Marque uma inspeção como realizada com observação e foto, outra pendente e outra sem retorno. Confirme que o painel gerencial recebe as mudanças após atualização (até aproximadamente 5 segundos).
4. Verifique que somente `gerencia` importa/fecha OS e que `pedro` pode executar inspeções.
5. Teste encerramento e exportação JSON, e confira se não é possível importar uma nova OS enquanto a anterior estiver aberta.
6. Reinicie o serviço e confirme que os registros e as fotos persistiram.

## 4. Segurança e operação

- HTTPS é obrigatório. Não compartilhe senhas nem publique credenciais no código.
- **Não considere esta versão aprovada para produção sem uma revisão de segurança**. Faltam proteções adicionais, incluindo mitigação de CSRF, limitação de tentativas de login, gestão/recuperação de contas e validação mais rigorosa de uploads. `HTTPS_ONLY=1` não substitui essas medidas.
- Os arquivos de imagem e dados de manutenção são potencialmente sensíveis. Defina política de acesso, retenção, backups e exclusão, conforme regras da empresa e LGPD aplicável.
- Faça backups **externos, criptografados e testados** do SQLite e das fotos. Para cópia consistente do SQLite em uso, utilize o mecanismo de backup SQLite; não copie somente o arquivo `.sqlite3` enquanto houver gravações/WAL.
- Verifique custos, limites e retenção de disco/backups diretamente no provedor antes de contratar. A configuração de 1 GB é apenas inicial e pode ser insuficiente para fotos.
- O ditado por voz pode depender de serviços externos do navegador; informe os usuários e avalie requisitos de privacidade.
- Esta versão requer conexão com a internet, não oferece uso offline e não envia alertas automaticamente.

## 5. Regras do PCM ainda pendentes de desenvolvimento

- Histórico consolidado de itens **Sem retorno — execução não comprovada**, com data original e próxima data por frequência.
- Reagendamento automático de itens explicitamente não executados, com motivo e exceção para risco crítico.
- Bloqueio de fechamento com revisão formal das pendências e riscos críticos.
- Relatório PDF de fechamento com fotos e ocorrências (hoje existe impressão do navegador e exportação JSON).
- Migração para PostgreSQL, armazenamento de objetos, backups automatizados e trilha de auditoria reforçada.

**Importante:** o app inicia com banco vazio. Nenhuma OS anterior ou planilha foi migrada, e nenhum status de execução foi presumido.
