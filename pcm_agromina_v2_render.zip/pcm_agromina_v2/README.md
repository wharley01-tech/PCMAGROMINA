# PCM Agromina — Versão 2 (servidor centralizado)

Aplicativo web responsivo com perfis **gerencia** e **pedro**, importação revisada de OS em PDF textual, checklist, fotos, ditado de voz conforme navegador, banco SQLite centralizado, histórico de alterações, exportação JSON e painel atualizado a cada 5 segundos.

## Iniciar no computador (teste em rede local)

1. Instale Python 3.11 ou superior.
2. Na pasta do projeto, instale: `pip install -r requirements.txt`.
3. Configure as variáveis `APP_SECRET`, `ADMIN_PASSWORD` e `PEDRO_PASSWORD` com valores fortes e exclusivos.
   - PowerShell: `$env:APP_SECRET="um-segredo-longo"; $env:ADMIN_PASSWORD="senha-forte-1"; $env:PEDRO_PASSWORD="senha-forte-2"`
   - Linux/macOS: `export APP_SECRET='um-segredo-longo' ADMIN_PASSWORD='senha-forte-1' PEDRO_PASSWORD='senha-forte-2'`
4. Execute: `uvicorn app:app --host 0.0.0.0 --port 8000`.
5. Acesse `http://localhost:8000` no computador. No celular na **mesma rede Wi-Fi**, use `http://IP-DO-COMPUTADOR:8000`, se o firewall permitir.
6. Login: usuário `gerencia` ou `pedro` e a senha configurada. O cadastro inicial ocorre na primeira inicialização do banco. **Não use senhas de teste em produção.**

## Publicar na internet

Use o `Dockerfile` em uma VPS ou plataforma com **disco persistente**. Configure `DATA_DIR=/app/data`, monte um volume persistente nessa pasta, configure os três segredos acima, ative **HTTPS** com domínio e proxy reverso e defina `HTTPS_ONLY=1`. Sem volume persistente, SQLite e fotos podem desaparecer em reinicializações. Faça backups frequentes do diretório `data` (banco e uploads), com retenção e acesso restrito. SQLite é adequado para equipe pequena/uma instância; para várias instâncias e alta concorrência, migrar para PostgreSQL e armazenamento de objetos.

## Fluxo

1. Gerência gera PDF oficial e importa o arquivo no aplicativo.
2. O leitor propõe dados e itens. **Revise e corrija todos**; PDF digitalizado não é reconhecido. O PDF original deve ser guardado no computador. O aplicativo guarda os dados revisados, não o PDF original.
3. Pedro abre a OS no celular, marca a situação, digita ou dita comentários, anexa fotos opcionais e salva. O painel da gerência atualiza a cada 5 segundos enquanto aberto.
4. A gerência exporta JSON de fechamento e, após conferência, fecha a OS. Uma OS aberta bloqueia a importação da próxima. **O sistema não gera automaticamente a OS seguinte.**

## Limitações importantes

- O extrator de PDF é heurístico e pode falhar em tabelas ou layouts diferentes. Sempre confira a quantidade de itens e os campos **setor/equipamento/atividade**. Para uso produtivo, recomenda-se padronizar o PDF com uma tabela legível e testar o modelo oficial.
- A opção “Sem retorno” significa execução não comprovada; não significa “Não executado”. A distinção é preservada no JSON.
- O reagendamento individual por frequência e o relatório histórico consolidado de itens sem retorno ainda não são automáticos nesta versão. Não trate a aplicação como substituto integral do controle mestre do PCM.
- O botão “Imprimir/PDF” usa a impressão do navegador. Relatório PDF fotográfico diagramado e anexação das fotos em PDF serão desenvolvidos em etapa posterior.
- O ditado de voz depende do suporte do navegador e de permissões de microfone/HTTPS. Alguns navegadores enviam áudio para serviços de transcrição do fornecedor.
- Não há sincronização offline: Pedro precisa de internet/rede durante a execução.
- Fotos são restritas a usuários autenticados, mas não há remoção/edição de fotos pela interface nesta versão.
- A implantação requer configuração de servidor, HTTPS, política de acesso, backup e testes de segurança antes de uso corporativo.
